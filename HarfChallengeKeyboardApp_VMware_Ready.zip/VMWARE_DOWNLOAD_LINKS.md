# 🔗 روابط التحميل المفيدة لـ VMware + macOS

## 🖥️ VMware Workstation Player

### التحميل الرسمي (مجاني)
```
https://www.vmware.com/products/workstation-player/workstation-player-evaluation.html
```

### متطلبات النظام
- **Windows 10/11** (64-bit)
- **RAM**: 8GB على الأقل (يفضل 16GB)
- **مساحة قرص**: 50GB على الأقل
- **معالج**: Intel/AMD متوافق مع virtualization

## 🍎 macOS

### خيار 1: تحميل من App Store (الأسهل)
```
https://apps.apple.com/us/app/macos-ventura/id1638787999
```
- افتح الرابط في macOS VM
- اضغط "Get" أو "Download"
- انتظر التحميل (قد يستغرق ساعة)

### خيار 2: ملفات ISO جاهزة
```
https://developer.apple.com/download/all/
```
- تحتاج Apple Developer Account (مجاني)
- ابحث عن "macOS"
- حمل أحدث إصدار متوافق

### خيار 3: مواقع بديلة (غير رسمية)
```
https://macos.gatekeeper.pw/
https://github.com/acidanthera/OpenCorePkg/releases
```
⚠️ **تحذير**: استخدم على مسؤوليتك الخاصة

## 🛠️ Xcode

### التحميل الرسمي
```
https://apps.apple.com/us/app/xcode/id497799835
```
- حجم التحميل: ~15GB
- وقت التحميل: 1-3 ساعات (حسب السرعة)
- متطلبات: macOS 12.0 أو أحدث

### Command Line Tools (بديل سريع)
```bash
# في Terminal:
xcode-select --install
```
- حجم أصغر (~500MB)
- مناسب للاختبار السريع

## 📦 ملفات إضافية مفيدة

### Homebrew (مدير الحزم)
```bash
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
```

### Git
```bash
# تثبيت عبر Homebrew
brew install git

# أو تحميل مباشر
https://git-scm.com/download/mac
```

## ⚙️ إعدادات VMware الموصى بها

### إعدادات الأجهزة
```
Memory: 16GB
Processors: 4 cores
Hard Disk: 100GB
Graphics: 2GB VRAM
Network: NAT
USB: USB 3.0
```

### إعدادات متقدمة
```
VM Settings → Options → Advanced:
- Enable 3D acceleration
- Enable hardware virtualization
- Enable nested paging
```

## 🔧 أدوات مساعدة

### VMware Tools
- يحسن الأداء
- يدعم Shared Folders
- يحسن دقة الشاشة

### Parallels Tools (بديل)
- إذا كنت تستخدم Parallels Desktop
- أداء أفضل من VMware

## 📱 iOS Simulator

### تحميل Simulators إضافية
```bash
# في Xcode:
# Window → Devices and Simulators
# اضغط + لإضافة Simulator جديد
```

### Simulators الموصى بها
- **iPhone 15** (أحدث)
- **iPhone 14** (متوازن)
- **iPad Pro** (للاختبار على iPad)

## 🎯 خطوات سريعة للبدء

### 1. تثبيت VMware
```bash
# 1. حمل VMware Workstation Player
# 2. ثبت البرنامج
# 3. أعد تشغيل الكمبيوتر
```

### 2. إنشاء macOS VM
```bash
# 1. Create New Virtual Machine
# 2. اختر macOS ISO
# 3. اضبط الإعدادات
# 4. ابدأ التثبيت
```

### 3. تثبيت Xcode
```bash
# 1. افتح App Store في macOS
# 2. ابحث عن Xcode
# 3. اضغط Download
# 4. انتظر التحميل
```

### 4. تشغيل التطبيق
```bash
# 1. انسخ ملف ZIP إلى macOS
# 2. فك الضغط
# 3. افتح .xcodeproj
# 4. اضغط Cmd + R
```

## 🚨 ملاحظات مهمة

### الأداء
- **RAM**: كلما زاد كلما كان أفضل
- **SSD**: أسرع من HDD
- **Virtualization**: تأكد من تفعيله في BIOS

### التوافق
- **macOS 12+**: مطلوب لـ Xcode 14+
- **Xcode 14+**: مطلوب لـ iOS 16+
- **VMware 16+**: مطلوب لـ macOS 12+

### الأمان
- استخدم روابط رسمية فقط
- احتفظ بنسخة احتياطية من VM
- لا تشارك معلومات حساسة

---

## 🎉 جاهز للبدء!

بعد تحميل هذه الملفات، اتبع دليل `VMWARE_MAC_SETUP.md` للبدء في تشغيل التطبيق التعليمي السعودي!

**🇸🇦 تطبيق تعليمي سعودي - يعمل على أي جهاز Windows!** 