import SwiftUI

struct SettingsView: View {
    var body: some View {
        VStack {
            Text("الإعدادات")
                .font(.largeTitle)
                .padding()
            Text("سيتم إضافة إعدادات اللعبة هنا لاحقًا.")
                .foregroundColor(.secondary)
        }
        .padding()
    }
} 