# 🖥️ دليل تشغيل التطبيق على macOS في VMware Workstation Player

## 🎯 إعداد البيئة

### المتطلبات الأساسية
- **VMware Workstation Player** (مجاني)
- **macOS ISO** (أو ملف .vmdk جاهز)
- **Xcode** (لتحميله داخل macOS)
- **مساحة قرص**: 50GB على الأقل

## 📥 تحميل وتثبيت macOS

### 1️⃣ تحميل VMware Workstation Player
```bash
# رابط التحميل الرسمي
https://www.vmware.com/products/workstation-player/workstation-player-evaluation.html
```

### 2️⃣ إعداد macOS VM
1. **إنشاء VM جديد**
   - اختر "Create a New Virtual Machine"
   - اختر "I will install the operating system later"
   - اختر "Apple Mac OS X" → "macOS 12" أو أحدث

2. **إعدادات الأجهزة المطلوبة**
   ```
   RAM: 8GB على الأقل (يفضل 16GB)
   CPU: 4 cores على الأقل
   Disk: 50GB على الأقل
   Graphics: 2GB VRAM
   ```

3. **تحميل macOS**
   - يمكنك تحميل macOS من App Store داخل VM
   - أو استخدام ملف ISO جاهز

## 🛠️ تثبيت Xcode

### 1️⃣ تحميل Xcode
```bash
# افتح App Store في macOS
# ابحث عن "Xcode"
# اضغط "Get" أو "Download"
# انتظر التحميل (قد يستغرق ساعة)
```

### 2️⃣ تثبيت Xcode
```bash
# بعد اكتمال التحميل
# افتح ملف Xcode.dmg
# اسحب Xcode إلى Applications
# افتح Xcode وقبل الترخيص
```

### 3️⃣ تثبيت Command Line Tools
```bash
# افتح Terminal في macOS
xcode-select --install
# اتبع التعليمات على الشاشة
```

## 🚀 تشغيل التطبيق

### 1️⃣ نقل الملفات
```bash
# انسخ ملف HarfChallengeKeyboardApp_Complete.zip إلى macOS
# يمكنك استخدام:
# - Shared Folders في VMware
# - USB Drive
# - Cloud Storage (Dropbox, Google Drive)
```

### 2️⃣ فك الضغط
```bash
# في macOS، اضغط مرتين على الملف
# أو استخدم Terminal:
unzip HarfChallengeKeyboardApp_Complete.zip
```

### 3️⃣ فتح المشروع
```bash
# اضغط مرتين على HarfChallengeKeyboard.xcodeproj
# أو استخدم Terminal:
open HarfChallengeKeyboard.xcodeproj
```

### 4️⃣ تشغيل التطبيق
1. **اختر Simulator**
   - في Xcode، اختر "iOS Simulator"
   - يفضل "iPhone 15" أو أحدث

2. **بناء وتشغيل**
   - اضغط `Cmd + R`
   - أو اضغط زر ▶️
   - انتظر حتى يفتح Simulator

## ⚡ تحسينات الأداء لـ VMware

### 1️⃣ إعدادات VMware
```
VM Settings → Hardware:
- Memory: 16GB (أو أكثر)
- Processors: 4 cores (أو أكثر)
- Graphics: 2GB VRAM
- Enable 3D acceleration
```

### 2️⃣ إعدادات macOS
```bash
# في macOS، افتح System Preferences
# Energy Saver → Turn off automatic graphics switching
# Displays → Scaled → More Space
```

### 3️⃣ تحسينات Xcode
```bash
# في Xcode:
# Preferences → Locations → Command Line Tools
# Preferences → Components → Download iOS Simulator
```

## 🎮 اختبار التطبيق

### لعبة الفرق التنافسية
1. اضغط "ابدأ اللعبة"
2. اختر فريقك (أخضر/أحمر)
3. اضغط على حرف وأجب على السؤال
4. استمتع بالتنافس!

### كيبورد الحروف
1. اضغط "كيبورد الحروف"
2. اضغط على أي حرف
3. اقرأ السؤال وأجب عليه
4. استمر حتى تنتهي جميع الحروف

## 🔧 استكشاف الأخطاء

### إذا كان Simulator بطيء:
```bash
# في Xcode:
# Window → Devices and Simulators
# اختر Simulator → Erase All Content and Settings
```

### إذا لم يفتح التطبيق:
```bash
# في Xcode:
# Product → Clean Build Folder (Cmd + Shift + K)
# Product → Build (Cmd + B)
```

### إذا لم تظهر الأسئلة:
- تأكد من وجود ملف `questions.json`
- اضغط "إعادة اللعبة"
- أعد تشغيل التطبيق

## 📱 نصائح للاستخدام

### تحسين الأداء:
- أغلق التطبيقات غير الضرورية في macOS
- استخدم Simulator واحد فقط
- تأكد من وجود مساحة كافية على القرص

### للاختبار:
- جرب جميع الحروف
- اختبر كلا الوضعين (الفرق والكيبورد)
- تأكد من عمل المؤقت
- اختبر زر إعادة اللعبة

## 🎯 الميزات المتاحة

✅ **لعبة الفرق**: تنافس أخضر vs أحمر  
✅ **كيبورد تفاعلي**: داخل التطبيق  
✅ **أسئلة سعودية**: 84 سؤال متنوع  
✅ **تصميم عربي**: RTL كامل  
✅ **مؤقت تفاعلي**: 10 ثواني  
✅ **نظام نقاط**: احتساب النقاط  
✅ **شاشة النتيجة**: إعلان الفائز  

---

## 🏆 جاهز للاستخدام!

بعد اتباع هذه التعليمات، ستحصل على:
- بيئة macOS كاملة في VMware
- Xcode مثبت ومجهز
- تطبيق تعليمي سعودي يعمل بشكل مثالي
- تجربة تعليمية ممتعة ومفيدة

**🇸🇦 تطبيق تعليمي سعودي - يعمل على أي جهاز Windows عبر VMware!** 