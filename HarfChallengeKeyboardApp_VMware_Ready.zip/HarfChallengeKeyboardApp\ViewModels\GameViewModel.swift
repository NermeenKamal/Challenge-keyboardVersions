import Foundation

class GameViewModel: ObservableObject {
    @Published var timeLeft: Int = 10
    @Published var timerActive: Bool = false
    @Published var showResult: Bool = false
    @Published var resultMessage: String = ""
    @Published var userAnswer: String = ""
    @Published var currentQuestion: GameQuestion? = nil
    
    private var timer: Timer?
    private var lastLetter: String? = nil
    private var lastCorrect: Bool = false
    
    private var questionsByLetter: [String: [GameQuestion]] = [:]
    
    init() {
        loadQuestions()
    }
    
    private func loadQuestions() {
        guard let url = Bundle.main.url(forResource: "questions", withExtension: "json"),
              let data = try? Data(contentsOf: url),
              let questions = try? JSONDecoder().decode([String: [GameQuestion]].self, from: data) else {
            print("Error loading questions")
            return
        }
        questionsByLetter = questions
    }
    
    func loadQuestionForLetter(_ letter: String) {
        guard let questions = questionsByLetter[letter], !questions.isEmpty else { return }
        
        currentQuestion = questions.randomElement()
        userAnswer = ""
        showResult = false
        resultMessage = ""
        timeLeft = 10
        timerActive = true
        lastLetter = letter
        lastCorrect = false
        
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] t in
            guard let self = self else { t.invalidate(); return }
            
            if self.timeLeft > 0 {
                self.timeLeft -= 1
            } else {
                t.invalidate()
                self.timerActive = false
                self.showResult = true
                self.resultMessage = "انتهى الوقت! الإجابة خاطئة."
                self.lastCorrect = false
            }
        }
    }
    
    func checkAnswerForLetter(_ letter: String) -> Bool {
        timer?.invalidate()
        timerActive = false
        
        let correct = userAnswer.trimmingCharacters(in: .whitespacesAndNewlines) == currentQuestion?.answer.trimmingCharacters(in: .whitespacesAndNewlines)
        
        showResult = true
        if correct {
            resultMessage = "إجابة صحيحة!"
        } else {
            resultMessage = "إجابة خاطئة. الإجابة الصحيحة: \(currentQuestion?.answer ?? "-")"
        }
        
        lastCorrect = correct
        return correct
    }
    
    func resetGame() {
        timeLeft = 10
        timerActive = false
        showResult = false
        resultMessage = ""
        userAnswer = ""
        currentQuestion = nil
        timer?.invalidate()
        lastLetter = nil
        lastCorrect = false
    }
} 