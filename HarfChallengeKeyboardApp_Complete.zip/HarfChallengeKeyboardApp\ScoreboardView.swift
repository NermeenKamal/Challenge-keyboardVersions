import SwiftUI

struct ScoreboardView: View {
    var body: some View {
        VStack {
            Text("لوحة النتائج")
                .font(.largeTitle)
                .padding()
            Text("سيتم عرض النتائج هنا لاحقًا.")
                .foregroundColor(.secondary)
        }
        .padding()
    }
} 