import Foundation

struct GameQuestion: Codable {
    let question: String
    let answer: String
} 