import SwiftUI

struct InstructionsView: View {
    var body: some View {
        VStack {
            Text("تعليمات اللعبة")
                .font(.largeTitle)
                .padding()
            Text("سيتم شرح طريقة اللعب هنا لاحقًا.")
                .foregroundColor(.secondary)
        }
        .padding()
    }
} 