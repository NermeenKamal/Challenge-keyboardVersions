import SwiftUI
import Foundation

@main
struct HarfChallengeKeyboardApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

struct ContentView: View {
    @State private var currentView: AppView = .welcome
    
    enum AppView {
        case welcome
        case game
        case keyboard
    }
    
    var body: some View {
        Group {
            switch currentView {
            case .welcome:
                WelcomeView(onStartGame: {
                    currentView = .game
                }, onStartKeyboard: {
                    currentView = .keyboard
                })
            case .game:
                GameView(onBack: {
                    currentView = .welcome
                })
            case .keyboard:
                KeyboardGameView(onBack: {
                    currentView = .welcome
                })
            }
        }
        .environment(\.layoutDirection, .rightToLeft)
    }
}

struct WelcomeView: View {
    let onStartGame: () -> Void
    let onStartKeyboard: () -> Void
    
    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [
                    Color.green.opacity(0.3),
                    Color.blue.opacity(0.3),
                    Color.purple.opacity(0.3)
                ]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            
            VStack(spacing: 40) {
                Spacer()
                
                VStack(spacing: 20) {
                    Text("🎮")
                        .font(.system(size: 80))
                    
                    Text("لعبة تحدي الحروف")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.primary)
                    
                    Text("تعلم الحروف العربية بطريقة ممتعة")
                        .font(.title2)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                }
                
                Spacer()
                
                VStack(spacing: 20) {
                    Button(action: onStartGame) {
                        HStack {
                            Image(systemName: "gamecontroller.fill")
                            Text("ابدأ اللعبة")
                        }
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.green)
                        .cornerRadius(15)
                        .shadow(radius: 5)
                    }
                    
                    Button(action: onStartKeyboard) {
                        HStack {
                            Image(systemName: "keyboard")
                            Text("كيبورد الحروف")
                        }
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .cornerRadius(15)
                        .shadow(radius: 5)
                    }
                }
                .padding(.horizontal, 40)
                
                Spacer()
                
                Text("🇸🇦 تطبيق تعليمي سعودي")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            .padding()
        }
    }
}

struct Question: Codable, Identifiable {
    let id = UUID()
    let question: String
    let answer: String
}

class GameViewModel: ObservableObject {
    @Published var questions: [Question] = []
    @Published var currentQuestion: Question?
    @Published var userAnswer: String = ""
    @Published var timeLeft: Int = 60
    @Published var showResult: Bool = false
    @Published var resultMessage: String = ""
    @Published var gameOver: Bool = false
    var timer: Timer?

    init() {
        loadQuestions()
        nextQuestion()
        startTimer()
    }

    func loadQuestions() {
        if let url = Bundle.main.url(forResource: "questions", withExtension: "json"),
           let data = try? Data(contentsOf: url),
           let loaded = try? JSONDecoder().decode([Question].self, from: data) {
            questions = loaded.shuffled()
        }
    }

    func nextQuestion() {
        userAnswer = ""
        showResult = false
        resultMessage = ""
        if !questions.isEmpty {
            currentQuestion = questions.removeFirst()
            timeLeft = 60
            startTimer()
        } else {
            gameOver = true
            stopTimer()
        }
    }

    func checkAnswer() {
        stopTimer()
        if userAnswer.trimmingCharacters(in: .whitespacesAndNewlines) == currentQuestion?.answer {
            resultMessage = "إجابة صحيحة!"
        } else {
            resultMessage = "إجابة خاطئة! الإجابة الصحيحة: \(currentQuestion?.answer ?? "")"
        }
        showResult = true
    }

    func startTimer() {
        stopTimer()
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] _ in
            guard let self = self else { return }
            if self.timeLeft > 0 {
                self.timeLeft -= 1
            } else {
                self.stopTimer()
                self.resultMessage = "انتهى الوقت! الإجابة الصحيحة: \(self.currentQuestion?.answer ?? "")"
                self.showResult = true
            }
        }
    }

    func stopTimer() {
        timer?.invalidate()
        timer = nil
    }
}

struct GameView: View {
    var onBack: () -> Void
    @StateObject private var viewModel = GameViewModel()
    @State private var selectedLetter: String? = nil
    @State private var selectedTeam: String? = nil // "green" or "red"
    @State private var usedLetters: [String: String] = [:] // [حرف: فريق]
    @State private var greenScore: Int = 0
    @State private var redScore: Int = 0
    
    let arabicLetters: [String] = [
        "ا","ب","ت","ث","ج","ح","خ","د","ذ","ر","ز","س","ش","ص","ض","ط","ظ","ع","غ","ف","ق","ك","ل","م","ن","ه","و","ي"
    ]
    
    var body: some View {
        VStack(spacing: 20) {
            HStack {
                Button("رجوع", action: onBack)
                    .padding(8)
                    .background(Color.red.opacity(0.2))
                    .cornerRadius(8)
                Spacer()
                Text("الوقت: \(viewModel.timeLeft)")
                    .font(.headline)
                    .foregroundColor(.purple)
                Spacer()
                Button("إعادة اللعبة") {
                    usedLetters = [:]
                    greenScore = 0
                    redScore = 0
                    selectedTeam = nil
                    selectedLetter = nil
                    viewModel.resetGame()
                }
                .padding(8)
                .background(Color.blue.opacity(0.2))
                .cornerRadius(8)
            }
            .padding(.horizontal)
            
            HStack(spacing: 32) {
                HStack {
                    Circle().fill(Color.green).frame(width: 16, height: 16)
                    Text("الفريق الأخضر: \(greenScore)")
                        .fontWeight(.bold)
                        .foregroundColor(.green)
                }
                HStack {
                    Circle().fill(Color.red).frame(width: 16, height: 16)
                    Text("الفريق الأحمر: \(redScore)")
                        .fontWeight(.bold)
                        .foregroundColor(.red)
                }
            }
            .font(.title3)
            .padding(.bottom, 8)
            
            HStack(spacing: 24) {
                Button(action: { selectedTeam = "green" }) {
                    HStack {
                        Circle().fill(Color.green).frame(width: 20, height: 20)
                        Text("الفريق الأخضر")
                    }
                    .padding(8)
                    .background(selectedTeam == "green" ? Color.green.opacity(0.2) : Color.clear)
                    .cornerRadius(8)
                }
                Button(action: { selectedTeam = "red" }) {
                    HStack {
                        Circle().fill(Color.red).frame(width: 20, height: 20)
                        Text("الفريق الأحمر")
                    }
                    .padding(8)
                    .background(selectedTeam == "red" ? Color.red.opacity(0.2) : Color.clear)
                    .cornerRadius(8)
                }
            }
            .font(.title3)
            .padding(.bottom, 8)
            
            Text("اختر فريقًا ثم اختر حرفًا لبدء السؤال")
                .font(.title3)
                .foregroundColor(.secondary)
            
            LazyVGrid(columns: Array(repeating: .init(), count: 7), spacing: 12) {
                ForEach(arabicLetters, id: \.self) { letter in
                    Button(action: {
                        if selectedTeam != nil && usedLetters[letter] == nil {
                            selectedLetter = letter
                            viewModel.loadQuestionForLetter(letter)
                        }
                    }) {
                        Text(letter)
                            .font(.title)
                            .fontWeight(.bold)
                            .frame(width: 44, height: 44)
                            .background(
                                RoundedRectangle(cornerRadius: 10)
                                    .fill(
                                        usedLetters[letter] == "green" ? Color.green.opacity(0.7) :
                                        usedLetters[letter] == "red" ? Color.red.opacity(0.7) :
                                        (selectedLetter == letter ? Color.blue.opacity(0.3) : Color.gray.opacity(0.15))
                                    )
                            )
                            .foregroundColor(.black)
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(
                                        usedLetters[letter] == "green" ? Color.green :
                                        usedLetters[letter] == "red" ? Color.red :
                                        (selectedLetter == letter ? Color.blue : Color.gray.opacity(0.3)), 
                                        lineWidth: 2
                                    )
                            )
                            .shadow(color: usedLetters[letter] != nil ? .black.opacity(0.2) : .clear, radius: 3)
                            .scaleEffect(selectedLetter == letter ? 1.1 : 1.0)
                            .animation(.easeInOut(duration: 0.2), value: selectedLetter)
                    }
                    .disabled(usedLetters[letter] != nil)
                }
            }
            .padding(.horizontal)
            
            if let letter = selectedLetter, let q = viewModel.currentQuestion {
                VStack(spacing: 12) {
                    Text("سؤال الحرف \(letter):")
                        .font(.headline)
                    Text(q.question)
                        .font(.title2)
                        .multilineTextAlignment(.center)
                        .padding()
                        .background(Color.yellow.opacity(0.2))
                        .cornerRadius(12)
                    TextField("اكتب الإجابة هنا", text: $viewModel.userAnswer)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .multilineTextAlignment(.center)
                        .font(.title2)
                        .padding(.horizontal)
                    Button("تحقق") {
                        let correct = viewModel.checkAnswerForLetter(letter)
                        if let team = selectedTeam {
                            usedLetters[letter] = team
                            if correct {
                                if team == "green" { greenScore += 1 } else { redScore += 1 }
                            }
                        }
                        selectedLetter = nil
                        selectedTeam = nil
                    }
                    .font(.title2)
                    .padding()
                    .background(Color.green)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                    .shadow(radius: 2)
                    .disabled(viewModel.userAnswer.isEmpty)
                    if viewModel.showResult {
                        Text(viewModel.resultMessage)
                            .font(.title3)
                            .foregroundColor(viewModel.resultMessage.contains("صحيحة") ? .green : .red)
                    }
                }
            }
            
            if usedLetters.count == arabicLetters.count {
                VStack(spacing: 20) {
                    Text("🎉 انتهت اللعبة! 🎉")
                        .font(.largeTitle)
                        .foregroundColor(.blue)
                        .fontWeight(.bold)
                    
                    VStack(spacing: 12) {
                        HStack {
                            Circle().fill(Color.green).frame(width: 20, height: 20)
                            Text("الفريق الأخضر: \(greenScore)")
                                .font(.title2)
                                .fontWeight(.bold)
                                .foregroundColor(.green)
                        }
                        HStack {
                            Circle().fill(Color.red).frame(width: 20, height: 20)
                            Text("الفريق الأحمر: \(redScore)")
                                .font(.title2)
                                .fontWeight(.bold)
                                .foregroundColor(.red)
                        }
                    }
                    .padding()
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(15)
                    
                    if greenScore > redScore {
                        Text("🏆 الفريق الأخضر فاز! 🏆")
                            .font(.title)
                            .foregroundColor(.green)
                            .fontWeight(.bold)
                    } else if redScore > greenScore {
                        Text("🏆 الفريق الأحمر فاز! 🏆")
                            .font(.title)
                            .foregroundColor(.red)
                            .fontWeight(.bold)
                    } else {
                        Text("🤝 تعادل! 🤝")
                            .font(.title)
                            .foregroundColor(.orange)
                            .fontWeight(.bold)
                    }
                    
                    Button("🔄 إعادة اللعبة") {
                        usedLetters = [:]
                        greenScore = 0
                        redScore = 0
                        selectedTeam = nil
                        selectedLetter = nil
                        viewModel.resetGame()
                    }
                    .font(.title2)
                    .fontWeight(.bold)
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(15)
                    .shadow(radius: 5)
                }
                .padding()
                .background(Color.white.opacity(0.9))
                .cornerRadius(20)
                .shadow(radius: 10)
            }
            
            Spacer()
        }
        .padding()
        .background(
            LinearGradient(gradient: Gradient(colors: [Color.green.opacity(0.08), Color.yellow.opacity(0.08)]), startPoint: .top, endPoint: .bottom)
        )
    }
}

struct KeyboardGameView: View {
    var onBack: () -> Void
    @StateObject private var keyboardViewModel = KeyboardGameViewModel()
    
    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack {
                Button("رجوع", action: onBack)
                    .padding(8)
                    .background(Color.blue.opacity(0.2))
                    .cornerRadius(8)
                Spacer()
                Text("كيبورد الحروف العربية")
                    .font(.headline)
                    .fontWeight(.bold)
                Spacer()
                Button("إعادة") {
                    keyboardViewModel.resetGame()
                }
                .padding(8)
                .background(Color.green.opacity(0.2))
                .cornerRadius(8)
            }
            .padding()
            .background(Color.gray.opacity(0.1))
            
            // Game Area
            VStack(spacing: 20) {
                if let currentQuestion = keyboardViewModel.currentQuestion {
                    VStack(spacing: 15) {
                        Text("السؤال:")
                            .font(.title2)
                            .fontWeight(.bold)
                        
                        Text(currentQuestion.question)
                            .font(.title3)
                            .multilineTextAlignment(.center)
                            .padding()
                            .background(Color.yellow.opacity(0.2))
                            .cornerRadius(12)
                        
                        TextField("اكتب إجابتك هنا", text: $keyboardViewModel.userAnswer)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .multilineTextAlignment(.center)
                            .font(.title2)
                            .padding(.horizontal)
                        
                        Button("تحقق من الإجابة") {
                            keyboardViewModel.checkAnswer()
                        }
                        .font(.title2)
                        .padding()
                        .background(Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                        .disabled(keyboardViewModel.userAnswer.isEmpty)
                        
                        if keyboardViewModel.showResult {
                            Text(keyboardViewModel.resultMessage)
                                .font(.title3)
                                .foregroundColor(keyboardViewModel.resultMessage.contains("صحيحة") ? .green : .red)
                                .padding()
                                .background(Color.gray.opacity(0.1))
                                .cornerRadius(8)
                        }
                    }
                } else {
                    Text("اضغط على أي حرف لبدء اللعبة")
                        .font(.title2)
                        .foregroundColor(.secondary)
                        .padding()
                }
            }
            .padding()
            
            // Keyboard Grid
            LazyVGrid(columns: Array(repeating: .init(), count: 7), spacing: 8) {
                ForEach(keyboardViewModel.arabicLetters, id: \.self) { letter in
                    Button(action: {
                        keyboardViewModel.selectLetter(letter)
                    }) {
                        Text(letter)
                            .font(.title2)
                            .fontWeight(.bold)
                            .frame(width: 40, height: 40)
                            .background(
                                RoundedRectangle(cornerRadius: 8)
                                    .fill(keyboardViewModel.usedLetters.contains(letter) ? Color.gray.opacity(0.3) : Color.blue.opacity(0.2))
                            )
                            .foregroundColor(.black)
                            .overlay(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(Color.blue.opacity(0.5), lineWidth: 1)
                            )
                    }
                    .disabled(keyboardViewModel.usedLetters.contains(letter))
                }
            }
            .padding()
            .background(Color.gray.opacity(0.05))
        }
        .background(Color.white)
    }
}

class KeyboardGameViewModel: ObservableObject {
    @Published var currentQuestion: GameQuestion? = nil
    @Published var userAnswer: String = ""
    @Published var showResult: Bool = false
    @Published var resultMessage: String = ""
    @Published var usedLetters: [String] = []
    
    let arabicLetters: [String] = [
        "ا","ب","ت","ث","ج","ح","خ","د","ذ","ر","ز","س","ش","ص","ض","ط","ظ","ع","غ","ف","ق","ك","ل","م","ن","ه","و","ي"
    ]
    
    private var questionsByLetter: [String: [GameQuestion]] = [:]
    
    init() {
        loadQuestions()
    }
    
    private func loadQuestions() {
        guard let url = Bundle.main.url(forResource: "questions", withExtension: "json"),
              let data = try? Data(contentsOf: url),
              let questions = try? JSONDecoder().decode([String: [GameQuestion]].self, from: data) else {
            print("Error loading questions")
            return
        }
        questionsByLetter = questions
    }
    
    func selectLetter(_ letter: String) {
        guard let questions = questionsByLetter[letter], !questions.isEmpty else { return }
        
        currentQuestion = questions.randomElement()
        userAnswer = ""
        showResult = false
        resultMessage = ""
    }
    
    func checkAnswer() {
        let correct = userAnswer.trimmingCharacters(in: .whitespacesAndNewlines) == currentQuestion?.answer.trimmingCharacters(in: .whitespacesAndNewlines)
        
        showResult = true
        if correct {
            resultMessage = "إجابة صحيحة! 🎉"
            if let letter = currentQuestion?.question.components(separatedBy: " ").first(where: { arabicLetters.contains($0) }) {
                usedLetters.append(letter)
            }
        } else {
            resultMessage = "إجابة خاطئة. الإجابة الصحيحة: \(currentQuestion?.answer ?? "-")"
        }
    }
    
    func resetGame() {
        currentQuestion = nil
        userAnswer = ""
        showResult = false
        resultMessage = ""
        usedLetters = []
    }
} 